#!/bin/bash
# Anime Partner — the whole Android build, run by .github/workflows/build-apk.yml.
# Inputs: ../index.html and ../icon-512.png from the repository root.
# Env:    VERSION_NAME, VERSION_CODE, ANDROID_HOME, optional KS / KS_PASS.
set -e
cd "$(dirname "$0")"

BT="$ANDROID_HOME/build-tools/34.0.0"
AJ="$ANDROID_HOME/platforms/android-34/android.jar"
VN="${VERSION_NAME:-1.43}"
VC="${VERSION_CODE:-146}"
KS="${KS:-release.p12}"
KS_PASS="${KS_PASS:-animepartner}"

test -f ../index.html   || { echo "::error::index.html must be in the repository root"; exit 1; }
test -f ../icon-512.png || { echo "::error::icon-512.png must be in the repository root"; exit 1; }
test -f "$BT/aapt2"     || { echo "::error::Android build-tools 34.0.0 not found"; exit 1; }

echo "--- version $VN ($VC) ---"
sed -i "s|android:versionCode=\"[0-9]*\"|android:versionCode=\"$VC\"|" AndroidManifest.xml
sed -i "s|android:versionName=\"[^\"]*\"|android:versionName=\"$VN\"|" AndroidManifest.xml

echo "--- launcher icons from icon-512.png ---"
python3 -m pip install --quiet --disable-pip-version-check pillow
python3 make-icons.py ../icon-512.png

echo "--- bundle the app + inject the speech bridge ---"
mkdir -p assets
cp -f ../index.html assets/index.html
python3 - <<'PY'
# Android's WebView has no Web Speech API, so the Japanese pronunciation buttons
# would be silent. MainActivity exposes the phone's TextToSpeech as AndroidTTS;
# this shim presents it to the page as window.speechSynthesis.
html = open('assets/index.html', encoding='utf-8').read()
shim = open('apk-bridge.js', encoding='utf-8').read()
assert '<head>' in html, 'no <head> found in index.html'
if 'apk-bridge' not in html:
    html = html.replace('<head>', '<head>\n<script>/* apk-bridge */\n' + shim + '\n</script>', 1)
    open('assets/index.html', 'w', encoding='utf-8').write(html)
    print('speech bridge injected:', len(shim), 'bytes')
else:
    print('bridge already present')
PY

echo "--- compile ---"
rm -rf build && mkdir -p build/compiled build/gen build/classes build/pack
"$BT/aapt2" compile --dir res -o build/compiled/res.zip
"$BT/aapt2" link -o build/base.apk -I "$AJ" --manifest AndroidManifest.xml \
  -R build/compiled/res.zip --java build/gen --auto-add-overlay \
  --min-sdk-version 21 --target-sdk-version 34
javac -nowarn -encoding UTF-8 -source 8 -target 8 -bootclasspath "$AJ" -classpath "$AJ" \
  -d build/classes $(find src build/gen -name "*.java")
"$BT/d8" --min-api 21 --output build/ $(find build/classes -name "*.class")

echo "--- package + sign ---"
cp build/base.apk build/unsigned.apk
cp build/classes.dex build/pack/
cp -r assets build/pack/
(cd build/pack && zip -q -X -r ../unsigned.apk classes.dex assets)
"$BT/zipalign" -p -f 4 build/unsigned.apk build/aligned.apk
"$BT/apksigner" sign --ks "$KS" --ks-pass "pass:$KS_PASS" --key-pass "pass:$KS_PASS" \
  --ks-key-alias animepartner --out ../anime-partner.apk build/aligned.apk
"$BT/apksigner" verify --verbose ../anime-partner.apk

cd ..
cp anime-partner.apk "anime-partner-v$VN-$VC.apk"
echo "APK ready: $(stat -c%s anime-partner.apk) bytes"
if [ -n "$GITHUB_OUTPUT" ]; then
  echo "tag=v$VN+$VC" >> "$GITHUB_OUTPUT"
  echo "title=Anime Partner $VN (build $VC)" >> "$GITHUB_OUTPUT"
fi
