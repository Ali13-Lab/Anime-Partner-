import os, sys
SRC = sys.argv[1]
from PIL import Image, ImageDraw, ImageFilter
import os
src = Image.open(SRC).convert("RGB")
DENS = {"mdpi":48,"hdpi":72,"xhdpi":96,"xxhdpi":144,"xxxhdpi":192}
FG   = {"mdpi":108,"hdpi":162,"xhdpi":216,"xxhdpi":324,"xxxhdpi":432}

def mark(px):
    S = 4                                    # supersample for clean edges
    w = px * S
    im = Image.new("RGBA", (w, w), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    c = w / 2
    R = w * 0.255                            # ring radius  -> diameter 51% (inside the 66% safe zone)
    t = int(w * 0.045)
    d.ellipse([c - R, c - R, c + R, c + R], outline=(255, 255, 255, 255), width=t)
    # play triangle with rounded corners: fill the polygon, then stroke its edges round-capped
    a = w * 0.115
    p = [(c - a * 0.78, c - a), (c - a * 0.78, c + a), (c + a * 0.92, c)]
    r = int(w * 0.055)
    d.polygon(p, fill=(255, 255, 255, 255))
    for i in range(3):
        d.line([p[i], p[(i + 1) % 3]], fill=(255, 255, 255, 255), width=r, joint="curve")
    for x, y in p:
        d.ellipse([x - r / 2, y - r / 2, x + r / 2, y + r / 2], fill=(255, 255, 255, 255))
    # four-point sparkle, upper right
    sx, sy, s = c + w * 0.105, c - w * 0.105, w * 0.052
    d.polygon([(sx, sy - s), (sx + s * 0.30, sy - s * 0.30), (sx + s, sy),
     (sx + s * 0.30, sy + s * 0.30), (sx, sy + s), (sx - s * 0.30, sy + s * 0.30),
     (sx - s, sy), (sx - s * 0.30, sy - s * 0.30)], fill=(255, 255, 255, 255))
    return im.resize((px, px), Image.LANCZOS)

for d, px in DENS.items():
    os.makedirs("res/mipmap-" + d, exist_ok=True)
    src.resize((px, px), Image.LANCZOS).save("res/mipmap-%s/ic_launcher.png" % d)
for d, px in FG.items():
    mark(px).save("res/mipmap-%s/ic_launcher_foreground.png" % d)
    src.resize((px, px), Image.LANCZOS).filter(ImageFilter.GaussianBlur(px * 0.22)) \
       .save("res/mipmap-%s/ic_launcher_background.png" % d)
print("icons generated from", SRC)
