package com.shin.animepartner;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import android.speech.tts.TextToSpeech;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Locale;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Anime Partner — Android shell.
 *
 * The whole app is one HTML file in assets, so this activity is deliberately
 * thin: create a WebView, let it keep its own storage, and hand any link that
 * points away from the app to the real browser. Nothing is added to the app
 * itself; the APK is the same web app, installed instead of bookmarked.
 *
 * Developed by Shin. Copyright reserved.
 */
public class MainActivity extends Activity {

  private WebView web;
  private TextToSpeech tts;
  private volatile boolean ttsReady = false;
  private volatile boolean japaneseOk = false;

  @SuppressLint("SetJavaScriptEnabled")
  @Override
  protected void onCreate(Bundle saved) {
    super.onCreate(saved);

    web = new WebView(this);
    web.setLayoutParams(new ViewGroup.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    web.setBackgroundColor(0xFF0B0D12);

    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);          // localStorage — the app's whole state
    s.setDatabaseEnabled(true);
    s.setMediaPlaybackRequiresUserGesture(true);
    s.setLoadWithOverviewMode(true);
    s.setUseWideViewPort(true);
    s.setSupportZoom(false);
    s.setAllowFileAccess(false);
    s.setAllowContentAccess(false);
    s.setCacheMode(WebSettings.LOAD_DEFAULT);
    if (Build.VERSION.SDK_INT >= 21) {
      s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    }

    web.setWebViewClient(new WebViewClient() {
      /* Anything that is not the bundled page — a streaming service, an
         Instagram profile, a YouTube video — belongs in the browser, not
         inside this shell. */
      @Override
      public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
        return openOutside(req.getUrl());
      }

      @Override
      @SuppressWarnings("deprecation")
      public boolean shouldOverrideUrlLoading(WebView view, String url) {
        return openOutside(Uri.parse(url));
      }

      private boolean openOutside(Uri uri) {
        String sc = uri.getScheme() == null ? "" : uri.getScheme();
        if (sc.equals("file")) return false;         // the app itself
        try {
          startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception ignored) {
          return false;
        }
        return true;
      }
    });

    web.setWebChromeClient(new WebChromeClient() {
      /* Android's WebView has no speech recogniser, so the only thing that
         could ask for a microphone here is something we did not ship.
         Deny it and let the app fall back to shadowing practice, which it
         already does properly. */
      @Override
      public void onPermissionRequest(final PermissionRequest request) {
        runOnUiThread(new Runnable() {
          @Override public void run() { request.deny(); }
        });
      }
    });

    /* The app writes two real files — the calendar reminder and the backup
       JSON — with a blob URL and an anchor click. A bare WebView ignores
       both, so the feature would look like it worked and leave nothing on
       the phone. This reads the blob back through JavaScript and writes it
       to the Downloads folder itself. */
    web.addJavascriptInterface(new FileBridge(), "AndroidFiles");

    /* Android's WebView ships no Web Speech API, so the Japanese lessons —
       "Hear it", "Read aloud", every pronunciation button — stay silent
       inside the APK even though they work in Chrome. The phone does have a
       speech engine, it is just not wired to the WebView. This hands the
       system TextToSpeech to the page; a small shim in the bundled HTML
       presents it as window.speechSynthesis, so the web app needs no
       Android-specific code of its own. */
    tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
      @Override
      public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS) return;
        ttsReady = true;
        try {
          int ja = tts.isLanguageAvailable(Locale.JAPANESE);
          japaneseOk = (ja == TextToSpeech.LANG_AVAILABLE
                     || ja == TextToSpeech.LANG_COUNTRY_AVAILABLE
                     || ja == TextToSpeech.LANG_COUNTRY_VAR_AVAILABLE);
        } catch (Exception ignored) { japaneseOk = false; }
      }
    });
    web.addJavascriptInterface(new SpeechBridge(), "AndroidTTS");
    web.setDownloadListener(new DownloadListener() {
      @Override
      public void onDownloadStart(String url, String agent, String disp, String mime, long size) {
        if (url != null && url.startsWith("blob:")) {
          web.evaluateJavascript(blobReader(url, mime), null);
          return;
        }
        try {
          startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
          toast("Could not open that download");
        }
      }
    });

    setContentView(web);
    hideBars();

    if (saved != null) web.restoreState(saved);
    else web.loadUrl("file:///android_asset/index.html");
  }

  /** Pulls a blob back into JavaScript as base64 and hands it to the app. */
  private static String blobReader(String url, String mime) {
    return "(function(){var x=new XMLHttpRequest();x.open('GET','" + url + "',true);"
        + "x.responseType='blob';x.onload=function(){var r=new FileReader();"
        + "r.onloadend=function(){AndroidFiles.save(r.result,'" + (mime == null ? "" : mime) + "');};"
        + "r.readAsDataURL(x.response);};x.send();})()";
  }

  /** Writes what the page produced into the phone's Downloads folder. */
  private class FileBridge {
    @JavascriptInterface
    public void save(String dataUrl, String mime) {
      try {
        int comma = dataUrl.indexOf(',');
        byte[] bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
        String ext = mime != null && mime.contains("calendar") ? ".ics" : ".json";
        String name = "anime-partner-" + System.currentTimeMillis() + ext;
        String where;
        if (Build.VERSION.SDK_INT >= 29) {
          ContentValues v = new ContentValues();
          v.put(MediaStore.Downloads.DISPLAY_NAME, name);
          v.put(MediaStore.Downloads.MIME_TYPE, mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
          Uri out = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
          OutputStream os = getContentResolver().openOutputStream(out);
          os.write(bytes);
          os.close();
          where = "Downloads/" + name;
        } else {
          File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
          if (!dir.exists()) dir.mkdirs();
          File f = new File(dir, name);
          FileOutputStream fo = new FileOutputStream(f);
          fo.write(bytes);
          fo.close();
          where = f.getAbsolutePath();
        }
        toast("Saved to " + where);
      } catch (Exception e) {
        toast("Could not save the file");
      }
    }
  }

  /** The phone's own speech engine, exposed to the page as window.speechSynthesis. */
  private class SpeechBridge {
    /** "ready|japanese" — the page decides what to tell the user from this. */
    @JavascriptInterface
    public String status() {
      return (ttsReady ? "1" : "0") + "|" + (japaneseOk ? "1" : "0");
    }

    @JavascriptInterface
    public void speak(final String text, final String lang, final float rate, final float volume) {
      if (!ttsReady || text == null || text.length() == 0) return;
      runOnUiThread(new Runnable() {
        @Override
        public void run() {
          try {
            Locale want = (lang != null && lang.toLowerCase(Locale.US).startsWith("ja"))
                ? Locale.JAPANESE : Locale.getDefault();
            tts.setLanguage(want);
            tts.setSpeechRate(rate > 0 ? rate : 1f);
            String id = "ap-" + System.currentTimeMillis();
            if (Build.VERSION.SDK_INT >= 21) {
              android.os.Bundle params = new android.os.Bundle();
              params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume <= 0 ? 1f : Math.min(1f, volume));
              tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, id);
            } else {
              tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
            }
          } catch (Exception ignored) { }
        }
      });
    }

    @JavascriptInterface
    public void stop() {
      runOnUiThread(new Runnable() {
        @Override public void run() { try { if (tts != null) tts.stop(); } catch (Exception ignored) { } }
      });
    }
  }

  private void toast(final String msg) {
    runOnUiThread(new Runnable() {
      @Override public void run() { Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show(); }
    });
  }

  private void hideBars() {
    if (Build.VERSION.SDK_INT >= 19) {
      getWindow().getDecorView().setSystemUiVisibility(
          View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }
  }

  @Override
  protected void onSaveInstanceState(Bundle out) {
    super.onSaveInstanceState(out);
    web.saveState(out);
  }

  /** Back goes back through the app's own screens before leaving it. */
  @Override
  public void onBackPressed() {
    if (web != null && web.canGoBack()) web.goBack();
    else super.onBackPressed();
  }

  @Override protected void onPause() { if (web != null) web.onPause(); if (tts != null) tts.stop(); super.onPause(); }
  @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }

  @Override
  protected void onDestroy() {
    if (tts != null) { try { tts.stop(); tts.shutdown(); } catch (Exception ignored) { } tts = null; }
    super.onDestroy();
  }
}
