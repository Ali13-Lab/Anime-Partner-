/* Anime Partner — APK-only shim. Injected into the copy of index.html that is
   bundled inside the Android app; the web build never sees it.

   Android's WebView implements no Web Speech API, so every pronunciation
   button in the Japanese lessons is silent inside the APK while working fine
   in Chrome. The phone's own speech engine is handed over by MainActivity as
   `AndroidTTS`; this presents it to the page as a normal `speechSynthesis`
   object, so js/core/tts.js keeps working untouched. */
(function () {
  if (typeof window === 'undefined' || !window.AndroidTTS) return;   // not inside the APK

  var st = '0|0';
  try { st = String(window.AndroidTTS.status() || '0|0'); } catch (e) { return; }
  var ready = st.charAt(0) === '1';
  var hasJa = st.charAt(2) === '1';

  function Utterance(text) {
    this.text = text == null ? '' : String(text);
    this.lang = 'ja-JP';
    this.rate = 1; this.pitch = 1; this.volume = 1;
    this.voice = null;
    this.onstart = null; this.onend = null; this.onerror = null;
  }

  function voiceList() {
    var out = [];
    if (hasJa) out.push({ name: 'Android speech engine', lang: 'ja-JP', voiceURI: 'android-ja', localService: true, 'default': true });
    out.push({ name: 'Android speech engine', lang: (navigator.language || 'en-US'), voiceURI: 'android-default', localService: true, 'default': !hasJa });
    return out;
  }

  var listeners = {};
  var synth = {
    speaking: false, pending: false, paused: false,
    getVoices: function () { return ready ? voiceList() : []; },
    speak: function (u) {
      if (!u) return;
      var text = String(u.text == null ? u : u.text);
      var lang = String(u.lang || 'ja-JP');
      var rate = Number(u.rate) > 0 ? Number(u.rate) : 1;
      var vol = u.volume == null ? 1 : Number(u.volume);
      try {
        window.AndroidTTS.speak(text, lang, rate, vol);
        synth.speaking = true;
        if (typeof u.onstart === 'function') { try { u.onstart({ type: 'start' }); } catch (e) {} }
        // The engine speaks on its own thread; approximate the end so UI state resets.
        var ms = Math.max(700, Math.round((text.length / Math.max(0.4, rate)) * 110));
        clearTimeout(synth._t);
        synth._t = setTimeout(function () {
          synth.speaking = false;
          if (typeof u.onend === 'function') { try { u.onend({ type: 'end' }); } catch (e) {} }
        }, ms);
      } catch (e) {
        synth.speaking = false;
        if (typeof u.onerror === 'function') { try { u.onerror({ type: 'error', error: String(e) }); } catch (e2) {} }
      }
    },
    cancel: function () {
      clearTimeout(synth._t);
      synth.speaking = false;
      try { window.AndroidTTS.stop(); } catch (e) {}
    },
    pause: function () { synth.cancel(); },
    resume: function () {},
    addEventListener: function (type, fn) { (listeners[type] = listeners[type] || []).push(fn); },
    removeEventListener: function (type, fn) {
      var a = listeners[type] || []; var i = a.indexOf(fn); if (i >= 0) a.splice(i, 1);
    },
    dispatchEvent: function () { return true; }
  };

  try {
    Object.defineProperty(window, 'speechSynthesis', { value: synth, configurable: true, writable: false });
  } catch (e) {
    window.speechSynthesis = synth;
  }
  window.SpeechSynthesisUtterance = Utterance;
  window.__AP_NATIVE_TTS__ = { ready: ready, japanese: hasJa };

  // Voices exist from the first moment here, but fire the event the page listens for anyway.
  setTimeout(function () {
    (listeners['voiceschanged'] || []).forEach(function (fn) { try { fn({ type: 'voiceschanged' }); } catch (e) {} });
  }, 0);
})();

/* ------------------------------------------------------------------ top bar --
   Two things can hide the page's top bar inside an Android shell:
   the status bar overlapping it (the page asks for viewport-fit=cover), and
   WebViews where `position: sticky` does not hold. This watches the real
   position of the bar and repairs whichever one went wrong. It does nothing
   on a phone where the bar already sits where it should.                     */
(function () {
  function start() {
    var bar = document.getElementById('topbar');
    if (!bar) { return setTimeout(start, 400); }

    var pad = 0;
    try {
      if (window.AndroidInsets && typeof AndroidInsets.top === 'function') {
        pad = Math.round(AndroidInsets.top());
      }
    } catch (e) { pad = 0; }
    if (pad > 0 && pad < 120) {
      bar.style.paddingTop = pad + 'px';
      bar.style.backgroundColor = getComputedStyle(document.body).backgroundColor;
    }

    var spacer = null;
    function check() {
      var r = bar.getBoundingClientRect();
      if (bar.style.position !== 'fixed' && r.top < -1) {
        // sticky is not holding — pin the bar and keep the page from jumping
        var h = r.height;
        spacer = document.createElement('div');
        spacer.style.height = h + 'px';
        bar.parentNode.insertBefore(spacer, bar.nextSibling);
        bar.style.position = 'fixed';
        bar.style.top = '0';
        bar.style.left = '0';
        bar.style.right = '0';
        bar.style.zIndex = '60';
        bar.style.backgroundColor = getComputedStyle(document.body).backgroundColor;
      }
    }
    addEventListener('scroll', check, { passive: true });
    addEventListener('resize', check);
    setTimeout(check, 600);
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else { start(); }
})();
